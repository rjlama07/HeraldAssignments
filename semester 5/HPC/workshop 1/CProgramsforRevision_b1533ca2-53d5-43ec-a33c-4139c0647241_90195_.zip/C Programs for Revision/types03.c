#include <stdlib.h>
#include <stdio.h>

int main() {
  float x = 10.0f;
  float y = 3.0f;

  printf("%f / %f = %f\n", x, y, x/y);
  return EXIT_SUCCESS;
}
