#include <stdlib.h>
#include <stdio.h>

int main() {
  int x = 10;
  int y = 3;

  printf("%d / %d = %d\n", x, y, x/y);
  return EXIT_SUCCESS;
}
