#include <stdlib.h>
#include <stdio.h>

int main() {
  double x = 10.0;
  double y = 3.0;

  printf("%lf / %lf = %lf\n", x, y, x/y);
  return EXIT_SUCCESS;
}
