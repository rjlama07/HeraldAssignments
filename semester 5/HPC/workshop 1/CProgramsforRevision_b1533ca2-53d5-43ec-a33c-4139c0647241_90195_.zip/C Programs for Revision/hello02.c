#include <stdlib.h>
#include <stdio.h>

int main() {
  int n = 19;
  printf("Hello\nMy favourite number is %d\n", n);
  return EXIT_SUCCESS;
}
